# mypackage

Returns the top n items in an array in descending order

## building this package locally
'python setup.py sdist'

## installing this package from GitHub
'pip install git+https://github.com/Keanu/example-python-package.git'

## updating this package from GitHub
'pip install --upgrade git+https://github.com/Keanu/example-python-package.git'
